module.exports = {
  AppID: "wx4ec6df040af98951", // 个人AppId
  AppSecret: "22c161094e3fec3294f50b8e33769345", // 个人AppSecret
}
