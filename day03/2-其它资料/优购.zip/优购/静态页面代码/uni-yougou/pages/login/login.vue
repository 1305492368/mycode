<template>
  <view>
    <button>点我登录</button>
  </view>
</template>

<script>
</script>

<style>
</style>